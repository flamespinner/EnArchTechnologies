<?php 
$headerstuff = NULL;
$pageTitle = "MPA Robotics - Template 2.0";
include('header.php');
?>

<div id="content" style="padding: 0px;">
<img src="images/templatedesign.png" alt="Design" style="width: 900px; margin-top:-5px;" />
</div>


<?php 
$footerstuff = NULL;
include('footer.php');
?>
