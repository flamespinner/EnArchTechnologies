<?php 
$headerstuff = '<style type="text/css">a{ color:#09F;}</style>';
$pageTitle = "MPA Robotics - Sponsors";
include('header.php');
flush();
?>

<div id="content">
	<div id="banner">
		<p>Special Thanks for our Sponsors</p>
	</div>
	
<div id="simages">
<div id="sponsor1">
<a href="http://www.jcpenney.com" id="sjcp"><img style="width:100%;" src="/images/jcpenney.png" alt="jcpenney Logo"></a>

<a href="http://www.nasa.gov" id="snasa"><img style="width:100%;" src="/images/NASA_logo.png" alt="NASA Logo"></a>
</div>

<div id="sponsor2">
<div id="saet">
<a href="http://www.aetrium.com" style="padding:10px;display:block;"><img src="/images/Aetrium-Logo.png" alt="Aetrium Logo"></a><br />With Thanks to the Levesque Family<br />
</div>
<div id="ssmc">
<a href="http://www.specialtymfg.com/" style="padding:10px;display:block;"><img src="/images/SMC-logo.gif" alt="Specialty Manufacturing Logo"></a><br />With Thanks to Daniel and Heidi McKeown, Jon Tomaszewski<br />
</div>
</div>

<div id="sponsor3">
<div id="sreell">
<a href="http://www.reell.com" style="padding:10px;display:block;"><img src="/images/REELL-logo.jpg" alt="REELL Manufacturing Logo"></a>
</div>
<div id="smpapa">
<a href="http://www.moundsparkacademy.org/currentfamilies/parentsassociation/" style="padding:10px;display:block;"><img src="/images/mpapa-logo.png" alt="Mounds Park Academy Parents Association logo"></a>
</div></div>


<br /><br />
<a style="font-size:25px;" href="http://www.homedepot.com">The Home Depot</a><br />
</div>

<h4 style="color:#000;">Additional thanks to Kablooe Design, Hubbard Broadcasting, The U of M Medical Devices Center, the U of M Engineering Department, PaR Systems, the 3M Innovation Center, Mr. Joe Springer and Dr. Joan Ireland, Mr. Soblavarro and Dr. Gromer, Mr. Gobran, and all of our mentors for their help and support.</h4>
</div>

<?php 
$footerstuff = NULL;
include('footer.php');
?>


