<?php
$headerstuff = NULL;
$pageTitle = "MPA Robotics - Template";
include ('header.php');
?>





<?php
$footerstuff = NULL;
include ('footer.php');
?>